USE sys;
CREATE DATABASE
IF
	NOT EXISTS ac_log DEFAULT CHARACTER 
	SET utf8 COLLATE utf8_general_ci;
USE ac_log;
CREATE TABLE
IF
	NOT EXISTS log(
		id INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
		time_stamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
		event_id INT DEFAULT - 1 CHECK ( event_id BETWEEN - 1 AND 6 ),
		room_id INT DEFAULT - 1 CHECK ( room_id >= - 1 ),
		server_id INT DEFAULT - 1 CHECK ( server_id BETWEEN - 1 AND 2 ),
		wait_id INT DEFAULT - 1 CHECK ( wait_id >= - 1 ),
		target_temp INT DEFAULT - 1,
		fan_speed INT DEFAULT 1 CHECK ( fan_speed BETWEEN 0 AND 2 ),
		current_temp FLOAT DEFAULT - 1,
		total_fee FLOAT DEFAULT 0 CHECK ( total_fee >= 0 ),
		serve_time INT DEFAULT 0 CHECK ( serve_time >= 0 ),
		fee_rate INT DEFAULT 0 CHECK ( fee_rate >= 0 ));